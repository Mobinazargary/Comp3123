function findLargest(a, b, c) {
    return Math.max(a, b, c);
}

// Example usage
console.log(findLargest(1, 0, 1));
console.log(findLargest(0, -10, -20));
console.log(findLargest(1000, 510, 440));    

